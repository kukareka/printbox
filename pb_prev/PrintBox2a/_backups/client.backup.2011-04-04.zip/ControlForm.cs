﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TermoPrinterLib;

namespace PrintBoxMain
{
    public partial class ControlForm : Form
    {
        private bool _cashCodeEnabled = false;
        public bool CashCodeEnabled { 
            get { return _cashCodeEnabled; }
            set { _cashCodeEnabled = pnlCashCode.Enabled = value; }
        }
        public ControlForm()
        {
            InitializeComponent();
            if (PrintBoxApp.Instance.FullScreen) TopMost = true;
        }

        private void buttonLoadTestDoc_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.LoadDocument(@"d:\blank.doc");
        }

        private void btn1uah_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.MoneyIn(1);
        }

        private void btn10uah_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.MoneyIn(10);
        }

        private void buttonOpenDrive_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.DriveIn(@"D:\");
        }

        private void buttonSendPing_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.server.SendPing();
        }

        private void buttonSend10uah_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.server.SendMoneyIn(textUser.Text, 10);
        }

        private void buttonLogin1_Click(object sender, EventArgs e)
        {
            string pwd = null;
            bool newUser = false;
            float balance = 0;
            PrintBoxApp.Instance.server.ReceiveAuthData(textUser.Text, ref pwd, ref newUser, ref balance);
            textPwd.Text = pwd;
            checkNewUser.Checked = newUser;
            textBalance.Text = balance.ToString("F2");
        }

        private void buttonSend10pages_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.server.SendSession(textUser.Text, 10, 0, 1);
        }

        private void buttonFixErrors_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.server.SendErrors(PrintBoxApp.Errors.ERROR_NONE);
        }

        private void buttonJamPaper_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.server.SendErrors(PrintBoxApp.Errors.ERROR_PRINTER_PAPER_JAM);
        }

        private void buttonShowInstruction_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.ShowInstruction(this);
        }

        private void buttonMessage_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.ShowMessage(this, "Сообщение");
        }

        private void buttonFixJam_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.server.SendErrors(PrintBoxApp.Errors.ERROR_NONE);
        }

        private void buttonFixNoPaper_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.server.SendErrors(PrintBoxApp.Errors.ERROR_NONE);
        }

        private void buttonNoPaper_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.server.SendErrors(PrintBoxApp.Errors.ERROR_PRINTER_NO_PAPER);
        }

        private void buttonCloseDrive_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.DriveOut();
        }

        private void buttonPrinterStatus_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.printer.Update();
            textPrinterStatus.Text = String.Format("{0}/{1}", PrintBoxApp.Instance.printer.Status.ToString(),
                    PrintBoxApp.Instance.printer.StatusText);
            textPrinterPages.Text = String.Format("{0}", PrintBoxApp.Instance.printer.PagesPrinted);
            textPrinterToner.Text = String.Format("{0}%", PrintBoxApp.Instance.printer.TonerRemaining);
        }

        private void buttonCashcodeReset_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.cashCode.Reset();
        }

        private void buttonCashcodeEnable_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.CashCodeEnabled = true;
            
        }

        private void buttonCashCodeDisable_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.CashCodeEnabled = false;
        }

        private void buttonPoll_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.cashCode.Poll();
            string newState = PrintBoxApp.Instance.cashCode.CurrentState.ToString();
            if (newState != textCashCodeStatus.Text) textCashCodeStatus.Text = newState;
        }

        private void buttonThermoStatus_Click(object sender, EventArgs e)
        {
            textThermoStatus.Text = PrintBoxApp.Instance.thermalPrinter.GetPrinterStatus().ToString();
        }

        private void buttonThermoTest_Click(object sender, EventArgs e)
        {
            TermoPrinter printer = PrintBoxApp.Instance.thermalPrinter;
            printer.Font = 1;
            printer.Bold = false;
            printer.Align = TermoPrinterLib.TextAlign.Center;
            printer.WriteLine("Центр");
            printer.Bold = true;
            printer.WriteLine("Центр bold");
            printer.WriteLine("");
            printer.Bold = false;
            printer.Align = TermoPrinterLib.TextAlign.Left;
            printer.WriteLine("Лево");
            printer.Align = TermoPrinterLib.TextAlign.Right;
            printer.WriteLine("Право");
            printer.Skip(200);
            printer.Cut();
        }

        private void buttonMaintenance_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.BeginMaintenance();
        }

        private void buttonCustomTest_Click(object sender, EventArgs e)
        {
            int i = 0;
            
            int j = 1 / i;
        }

        private void buttonPrintErrorCheck_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.sessionInfo = new PrintBoxApp.SessionInfo();
            PrintBoxApp.Instance.sessionInfo.userPhone = "380222222222";
            PrintBoxApp.Instance.sessionInfo.moneyInSession = 2;
            PrintBoxApp.Instance.sessionInfo.userMoney = 201.5F;
            PrintBoxApp.Instance.PrintErrorCheck();
        }

        private void textTime_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            uint realCode = PrintBoxApp.Instance.CalculateErrorCode(textPhone.Text, textTime.Text, textTerminal.Text, textError.Text, textMoneyIn.Text, textBalanceA.Text);
            if (realCode.ToString() == textCode.Text) MessageBox.Show("Правильно");
            else MessageBox.Show("Неправильно");
        }
    }
}

