﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Configuration;
using System.Threading;
using System.Text.RegularExpressions;
using HtmlRichText;

namespace PrintBoxMain
{
    public partial class InstructionForm : Form
    {
        public InstructionForm()
        {
            WinApi.SuspendDrawing(this);
            InitializeComponent();
            InitPanels();
            LoadInstruction();
            WinApi.ResumeDrawing(this);
        }

        public void InitPanels()
        {
            //pnlMain.Top = 0;
            //pnlMain.Left = 36;
            //pnlMain.Height = this.Height;
            //pnlMain.Width = this.Width - 2 * pnlMain.Left;
            //pnlInstructionContainer.Top = 10;
            //pnlInstructionContainer.Left = (pnlMain.Width - pnlInstructionContainer.Width) / 2;
            //pnlInstructionContainer.Height = 915;
            //txtInstruction.Left = 20;
            //txtInstruction.Width = 660;
            //txtInstruction.Top = 112;
            //txtInstruction.Height = pnlInstructionContainer.Height - txtInstruction.Top - 18;
            //btnCloseInstruction.Top = pnlInstructionContainer.Bottom + 10;
            btnCloseInstruction.Left = (btnCloseInstruction.Parent.Width - btnCloseInstruction.Width) / 2;
        }

        public void LoadInstruction()
        {
            txtInstruction.AddHTML(ResourcesMessages.instructionHTML);
        }

        private void btnCloseInstruction_MouseDown(object sender, MouseEventArgs e)
        {
            this.Hide();
        }

        private void txtInstruction_Enter(object sender, EventArgs e)
        {
            btnCloseInstruction.Focus();
        }
    }
}
