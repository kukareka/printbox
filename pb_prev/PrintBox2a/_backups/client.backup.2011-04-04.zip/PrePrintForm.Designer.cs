﻿namespace PrintBoxMain
{
    partial class PrePrintForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PrePrintForm));
            this.pnlWord = new System.Windows.Forms.Panel();
            this.lblCurrentPageInfo = new System.Windows.Forms.Label();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlNavigationButtons = new System.Windows.Forms.Panel();
            this.btnNext = new System.Windows.Forms.ImageButton();
            this.btnBack = new System.Windows.Forms.ImageButton();
            this.btnPrint = new System.Windows.Forms.ImageButton();
            this.btnCancelPrint = new System.Windows.Forms.ImageButton();
            this.lblBoxID = new System.Windows.Forms.Label();
            this.btnScrollDown = new System.Windows.Forms.ImageButton();
            this.btnScrollUp = new System.Windows.Forms.ImageButton();
            this.pnlMain.SuspendLayout();
            this.pnlNavigationButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnNext)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnPrint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancelPrint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnScrollDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnScrollUp)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlWord
            // 
            this.pnlWord.BackColor = System.Drawing.Color.White;
            this.pnlWord.Enabled = false;
            this.pnlWord.Location = new System.Drawing.Point(34, 85);
            this.pnlWord.Name = "pnlWord";
            this.pnlWord.Size = new System.Drawing.Size(384, 404);
            this.pnlWord.TabIndex = 0;
            // 
            // lblCurrentPageInfo
            // 
            this.lblCurrentPageInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCurrentPageInfo.BackColor = System.Drawing.Color.Transparent;
            this.lblCurrentPageInfo.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCurrentPageInfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(70)))), ((int)(((byte)(123)))));
            this.lblCurrentPageInfo.Location = new System.Drawing.Point(13, 640);
            this.lblCurrentPageInfo.Name = "lblCurrentPageInfo";
            this.lblCurrentPageInfo.Size = new System.Drawing.Size(414, 40);
            this.lblCurrentPageInfo.TabIndex = 90;
            this.lblCurrentPageInfo.Text = " Сторінка 1 з 1";
            this.lblCurrentPageInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlMain
            // 
            this.pnlMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlMain.BackgroundImage")));
            this.pnlMain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlMain.Controls.Add(this.pnlNavigationButtons);
            this.pnlMain.Controls.Add(this.lblBoxID);
            this.pnlMain.Controls.Add(this.btnScrollDown);
            this.pnlMain.Controls.Add(this.btnScrollUp);
            this.pnlMain.Controls.Add(this.pnlWord);
            this.pnlMain.Controls.Add(this.lblCurrentPageInfo);
            this.pnlMain.Location = new System.Drawing.Point(10, 17);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1040, 708);
            this.pnlMain.TabIndex = 91;
            // 
            // pnlNavigationButtons
            // 
            this.pnlNavigationButtons.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlNavigationButtons.BackColor = System.Drawing.Color.Transparent;
            this.pnlNavigationButtons.Controls.Add(this.btnNext);
            this.pnlNavigationButtons.Controls.Add(this.btnBack);
            this.pnlNavigationButtons.Controls.Add(this.btnPrint);
            this.pnlNavigationButtons.Controls.Add(this.btnCancelPrint);
            this.pnlNavigationButtons.Location = new System.Drawing.Point(472, 621);
            this.pnlNavigationButtons.Margin = new System.Windows.Forms.Padding(0);
            this.pnlNavigationButtons.Name = "pnlNavigationButtons";
            this.pnlNavigationButtons.Size = new System.Drawing.Size(561, 77);
            this.pnlNavigationButtons.TabIndex = 99;
            // 
            // btnNext
            // 
            this.btnNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNext.BackColor = System.Drawing.Color.Transparent;
            this.btnNext.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnNext.DownImage = null;
            this.btnNext.HoverImage = null;
            this.btnNext.Location = new System.Drawing.Point(420, 0);
            this.btnNext.Name = "btnNext";
            this.btnNext.NormalImage = global::PrintBoxMain.ResourcesMessages.preprint_next;
            this.btnNext.Size = new System.Drawing.Size(141, 77);
            this.btnNext.TabIndex = 94;
            this.btnNext.TabStop = false;
            this.btnNext.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnNext_MouseDown);
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.BackColor = System.Drawing.Color.Transparent;
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnBack.DownImage = null;
            this.btnBack.HoverImage = null;
            this.btnBack.Location = new System.Drawing.Point(0, 0);
            this.btnBack.Name = "btnBack";
            this.btnBack.NormalImage = global::PrintBoxMain.ResourcesMessages.preprint_back;
            this.btnBack.Size = new System.Drawing.Size(141, 77);
            this.btnBack.TabIndex = 96;
            this.btnBack.TabStop = false;
            this.btnBack.Visible = false;
            this.btnBack.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnBack_MouseDown);
            // 
            // btnPrint
            // 
            this.btnPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPrint.BackColor = System.Drawing.Color.Transparent;
            this.btnPrint.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnPrint.DownImage = null;
            this.btnPrint.HoverImage = null;
            this.btnPrint.Location = new System.Drawing.Point(348, 0);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.NormalImage = global::PrintBoxMain.ResourcesMessages.preprint_print;
            this.btnPrint.Size = new System.Drawing.Size(213, 77);
            this.btnPrint.TabIndex = 97;
            this.btnPrint.TabStop = false;
            this.btnPrint.Visible = false;
            this.btnPrint.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnPrint_MouseDown);
            // 
            // btnCancelPrint
            // 
            this.btnCancelPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancelPrint.BackColor = System.Drawing.Color.Transparent;
            this.btnCancelPrint.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnCancelPrint.DownImage = null;
            this.btnCancelPrint.HoverImage = null;
            this.btnCancelPrint.Location = new System.Drawing.Point(144, 0);
            this.btnCancelPrint.Name = "btnCancelPrint";
            this.btnCancelPrint.NormalImage = global::PrintBoxMain.ResourcesMessages.preprint_cancel;
            this.btnCancelPrint.Size = new System.Drawing.Size(201, 77);
            this.btnCancelPrint.TabIndex = 95;
            this.btnCancelPrint.TabStop = false;
            this.btnCancelPrint.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnCancelPrint_MouseDown);
            // 
            // lblBoxID
            // 
            this.lblBoxID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblBoxID.BackColor = System.Drawing.Color.White;
            this.lblBoxID.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblBoxID.Location = new System.Drawing.Point(3, 677);
            this.lblBoxID.Margin = new System.Windows.Forms.Padding(3);
            this.lblBoxID.Name = "lblBoxID";
            this.lblBoxID.Size = new System.Drawing.Size(200, 28);
            this.lblBoxID.TabIndex = 98;
            this.lblBoxID.Text = "ID термінала:";
            this.lblBoxID.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // btnScrollDown
            // 
            this.btnScrollDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnScrollDown.BackColor = System.Drawing.Color.Transparent;
            this.btnScrollDown.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnScrollDown.DownImage = global::PrintBoxMain.ResourcesMessages.scroll_button_down_clicked;
            this.btnScrollDown.HoverImage = null;
            this.btnScrollDown.Location = new System.Drawing.Point(665, 517);
            this.btnScrollDown.Margin = new System.Windows.Forms.Padding(0);
            this.btnScrollDown.Name = "btnScrollDown";
            this.btnScrollDown.NormalImage = global::PrintBoxMain.ResourcesMessages.scroll_button_down;
            this.btnScrollDown.Size = new System.Drawing.Size(78, 78);
            this.btnScrollDown.TabIndex = 93;
            this.btnScrollDown.TabStop = false;
            this.btnScrollDown.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnScrollDown_MouseDown);
            // 
            // btnScrollUp
            // 
            this.btnScrollUp.BackColor = System.Drawing.Color.Transparent;
            this.btnScrollUp.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnScrollUp.DownImage = global::PrintBoxMain.ResourcesMessages.scroll_button_up_clicked;
            this.btnScrollUp.HoverImage = null;
            this.btnScrollUp.Location = new System.Drawing.Point(665, 10);
            this.btnScrollUp.Margin = new System.Windows.Forms.Padding(0);
            this.btnScrollUp.Name = "btnScrollUp";
            this.btnScrollUp.NormalImage = global::PrintBoxMain.ResourcesMessages.scroll_button_up;
            this.btnScrollUp.Size = new System.Drawing.Size(78, 78);
            this.btnScrollUp.TabIndex = 92;
            this.btnScrollUp.TabStop = false;
            this.btnScrollUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnScrollUp_MouseDown);
            // 
            // PrePrintForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1060, 742);
            this.ControlBox = false;
            this.Controls.Add(this.pnlMain);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PrePrintForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Deactivate += new System.EventHandler(this.PrePrintForm_Deactivate);
            this.Activated += new System.EventHandler(this.PrePrintForm_Activated);
            this.pnlMain.ResumeLayout(false);
            this.pnlNavigationButtons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnNext)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnPrint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancelPrint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnScrollDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnScrollUp)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlWord;
        private System.Windows.Forms.Label lblCurrentPageInfo;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.ImageButton btnScrollDown;
        private System.Windows.Forms.ImageButton btnScrollUp;
        private System.Windows.Forms.ImageButton btnCancelPrint;
        private System.Windows.Forms.ImageButton btnNext;
        private System.Windows.Forms.ImageButton btnBack;
        private System.Windows.Forms.ImageButton btnPrint;
        private System.Windows.Forms.Label lblBoxID;
        private System.Windows.Forms.Panel pnlNavigationButtons;
        private MoneyInputParamsForm frmMoneyInputParams;
        public PrintParamsForm frmPrintParams;

        public System.Windows.Forms.Panel WordPanel { get { return pnlWord; } }
    }
}