﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using System.Diagnostics;

namespace PrintBoxMain
{
    public partial class PrintParamsForm : Form
    {
        private TextBox _currentTextBox;
        private string _currentTextBoxPrevValue;

        private string CurrentTextBoxPrevValue { get { return _currentTextBoxPrevValue; } }
        private TextBox CurrentTextBox
        {
            get { return _currentTextBox; }
            set
            {
                _currentTextBox = value;
                _currentTextBoxPrevValue = _currentTextBox.Text;
            }
        } //for kpanel

        private int _pagesPerSheet = 0;
        private int PagesPerSheet
        {
            get { return _pagesPerSheet; }
            set
            {
                if (_pagesPerSheet != value)
                {
                    _pagesPerSheet = value;
                    string imgOff = "NormalImage", imgOn = "DownImage", img1, img2, img4;
                    int tag1, tag2, tag4;
                    img1 = img2 = img4 = imgOff;
                    tag1 = tag2 = tag4 = 0;
                    if (value == 1) { img1 = imgOn; tag1 = 1; }
                    else if (value == 2) { img2 = imgOn; tag2 = 1; }
                    else if (value == 4) { img4 = imgOn; tag4 = 1; }
                    btnOnePage.NormalImage = ((System.Drawing.Image)(resources.GetObject("btnOnePage." + img1)));
                    btnTwoPages.NormalImage = ((System.Drawing.Image)(resources.GetObject("btnTwoPages." + img2)));
                    btnFourPages.NormalImage = ((System.Drawing.Image)(resources.GetObject("btnFourPages." + img4)));
                    btnOnePage.Tag = tag1;
                    btnTwoPages.Tag = tag2;
                    btnFourPages.Tag = tag4;
                    if (value != 1)
                    {
                        txtFrom.Text = "1";
                        txtTo.Text = PrintBoxApp.Instance.sessionInfo.pagesInDoc.ToString();
                    }
                    RecalcPrice();
                }
            }
        }

        private System.ComponentModel.ComponentResourceManager resources;

        public PrintParamsForm()
        {
            WinApi.SuspendDrawing(this);
            InitializeComponent();
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer, true);
            resources = new ComponentResourceManager(typeof(PrintParamsForm));
            if (PrintBoxApp.Instance.TopMost) TopMost = true;
            //pbApp = PrintBoxApp.GetInstance;
            //if (!pbApp.DebugMode) Cursor.Hide();
            WinApi.ResumeDrawing(this);
        }

        private void InitForm()
        {
            //btnInstruction.Top = 20;
            //btnInstruction.Left = pnlControls.Width - btnInstruction.Width - 20;
        }

        public void LoadPrintOptions()
        {
            string fullName = PrintBoxApp.Instance.sessionInfo.docName;
            string docName = fullName;
            int maxWidth = txtDocName.Width + txtDocName.Padding.Horizontal;
            int maxLength = docName.Length;
            while (TextRenderer.MeasureText(docName, txtDocName.Font).Width > maxWidth)
            {
                maxLength--;
                docName = fullName.Substring(0, maxLength) + "...";
            }
            
            txtDocName.Text = docName;
            txtPagesTotal.Text = PrintBoxApp.Instance.sessionInfo.pagesInDoc.ToString();
            txtCopyNumber.Text = "1";
            txtFrom.Text = "1";
            txtTo.Text = PrintBoxApp.Instance.sessionInfo.pagesInDoc.ToString();
            txtOnePagePrintCost.Text = (PrintBoxApp.Instance.config.PageCost * 0.01F).ToString("F2");
            PagesPerSheet = 1;
        }

        private static int CalcPages(int copies, int from, int to, int pps)
        {
            return copies * ((to - from + pps) / pps);
        }

        private void RecalcPrice()
        {
            if (PagesPerSheet == 0) return;
            try
            {
                PrintBoxApp.Instance.printOptions.pagesPerSheet = PagesPerSheet;
                PrintBoxApp.Instance.printOptions.copies = Convert.ToInt32(txtCopyNumber.Text);
                if (PrintBoxApp.Instance.printOptions.copies > 150) throw new FormatException();
                PrintBoxApp.Instance.printOptions.from = Convert.ToInt32(txtFrom.Text);
                PrintBoxApp.Instance.printOptions.to = Convert.ToInt32(txtTo.Text);
                if (PrintBoxApp.Instance.printOptions.to < PrintBoxApp.Instance.printOptions.from) throw new FormatException();
                PrintBoxApp.Instance.printOptions.pagesToPrint = CalcPages(PrintBoxApp.Instance.printOptions.copies,
                    PrintBoxApp.Instance.printOptions.from,
                    PrintBoxApp.Instance.printOptions.to,
                     PrintBoxApp.Instance.printOptions.pagesPerSheet);
                PrintBoxApp.Instance.printOptions.printCost = 
                    ((float)PrintBoxApp.Instance.printOptions.pagesToPrint * (float)PrintBoxApp.Instance.config.PageCost * 0.01F);
                PrintBoxApp.Instance.printOptions.valid = true;

                txtPagesTotalForPrint.Text = PrintBoxApp.Instance.printOptions.pagesToPrint.ToString();
                txtPrintCost.Text = PrintBoxApp.Instance.printOptions.printCost.ToString("F2");                
            }
            catch (FormatException)
            {
                txtPagesTotalForPrint.Text = txtPrintCost.Text = "";
                PrintBoxApp.Instance.printOptions.valid = false;
            }
        }

        private void NumberUpDown_TextChanged(object sender, EventArgs e)
        {
            TextBox senderTextBox = sender as TextBox;
            if (senderTextBox.Text.Length > 0)
            {
                int num = 1;
                try { num = Convert.ToInt32(senderTextBox.Text); }
                catch (FormatException) { }
                if (num < 1) num = 1;

                if ((senderTextBox == txtFrom) || (senderTextBox == txtTo))
                {
                    int maxValue = PrintBoxApp.Instance.sessionInfo.pagesInDoc;
                    if (num > maxValue) num = maxValue;
                    if ((senderTextBox == txtFrom) && (num != 1)) PagesPerSheet = 1;
                    if ((senderTextBox == txtTo) && (num != maxValue)) PagesPerSheet = 1;
                }
                senderTextBox.Text = num.ToString();
            }
            RecalcPrice();
            FocusTextBox(senderTextBox);
        }

        private void btnOnePage_Click(object sender, EventArgs e)
        {
            PagesPerSheet = 1;
        }

        private void btnTwoPages_Click(object sender, EventArgs e)
        {
            PagesPerSheet = 2;
        }

        private void btnFourPages_Click(object sender, EventArgs e)
        {
            PagesPerSheet = 4;
        }


        private void btnInstruction_MouseDown(object sender, MouseEventArgs e)
        {
            PrintBoxApp.Instance.ShowInstruction(this.Owner);
        }

        private void btnIncrease_MouseDown(object sender, MouseEventArgs e)
        {
            TextBox box = null;
            if (sender == btnIncreaseCopyNumber) box = txtCopyNumber;
            else if (sender == btnIncreaseFrom) box = txtFrom;
            else if (sender == btnIncreaseTo) box = txtTo;

            try
            {
                int num = Convert.ToInt32(box.Text);
                box.Text = (++num).ToString();
            }
            catch (FormatException)
            {
            }
        }

        private void btnDecrease_MouseDown(object sender, MouseEventArgs e)
        {
            TextBox box = null;
            if (sender == btnDecreaseCopyNumber)
            {
                box = txtCopyNumber;
            }
            else if (sender == btnDecreaseFrom)
            {
                box = txtFrom;
            }
            else if (sender == btnDecreaseTo)
            {
                box = txtTo;
            }
            try
            {
                int num = Convert.ToInt32(box.Text);
                box.Text = (--num).ToString();
            }
            catch (FormatException)
            {
            }
        }

        private void kBtn_MouseDown(object sender, MouseEventArgs e)
        {
            if (CurrentTextBox.Text.Length < 4)
            {
                CurrentTextBox.Text += (sender as ImageButton).Text;
            }
        }

        private void kBtnOkCancel_MouseDown(object sender, MouseEventArgs e)
        {
            if (sender == kBtnCancel) CurrentTextBox.Text = CurrentTextBoxPrevValue;
            kPanel.Visible = false;
            ShowHidePrintCostInfo(true);
        }

        private void kBtnBackspace_MouseDown(object sender, MouseEventArgs e)
        {
            if (CurrentTextBox.Text.Length > 0) CurrentTextBox.Text = CurrentTextBox.Text.Substring(0, CurrentTextBox.Text.Length - 1);
        }

        private void ShowHidePrintCostInfo(bool flag)
        {
            lblOnePagePrintCost.Visible = flag;
            lblPrintCost.Visible = flag;
            pnlOnePagePrintCost.Visible = flag;
            pnlPrintCost.Visible = flag;
        }

        private void FocusTextBox(TextBox textBox)
        {
            textBox.SelectionStart = textBox.Text.Length;
            textBox.SelectionLength = 0;
            textBox.Focus();
        }

        private void ShowKPanel(object sender, MouseEventArgs e)
        {
            ShowHidePrintCostInfo(false);
            CurrentTextBox = sender as TextBox;
            FocusTextBox(CurrentTextBox);
            kPanel.Visible = true;
        }
    }
}
