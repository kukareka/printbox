﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Threading;
using System.Diagnostics;

namespace PrintBoxMain
{
    public partial class PrintForm : Form
    {
        public PrintForm()
        {
            WinApi.SuspendDrawing(this);
            InitializeComponent();
            InitForm();
            AlignButtons();
            WinApi.ResumeDrawing(this);
        }

        private void InitForm()
        {
            //pnlMain.Top = 0;
            //pnlMain.Left = 36;
            //pnlMain.Height = this.Height;
            //pnlMain.Width = this.Width - 2 * pnlMain.Left;
            //pnlMain.Left = (pnlMain.Width - pnlControlContainer.Width) / 2;
            //pnlMain.Top = btnInstruction.Bottom;
            //btnInstruction.Left = pnlMain.Width - btnInstruction.Width - 28;
            //btnInstruction.Top = 23;
            //lblBoxID.Left = 3;
            //lblBoxID.Top = pnlMain.Height - 55;
            lblBoxID.Text = ResourcesMessages.txtBoxID.Replace("<!--BoxID-->", PrintBoxApp.Instance.config.BoxID.ToString());
        }

        private void AlignButtons()
        {
            if (btnPrintMore.Visible)
            {
                int space = 50;
                int blockWidth = btnLeave.Width + btnPrintMore.Width + space;
                int blockStart = (btnLeave.Parent.Width - blockWidth) / 2;
                btnLeave.Left = blockStart;
                btnPrintMore.Left = blockStart + btnLeave.Width + space;
            }
            else
            {
                btnLeave.Left = (btnLeave.Parent.Width - btnLeave.Width) / 2;
            }
        }

        public void PrintDone(bool success, bool flashEjected)
        {
            btnLeave.Visible = true;
            if (!success)
            {
                txtPrintingInfo.Text = ResourcesMessages.txtPrintError + "\r\n" + ResourcesMessages.txtMoneyReturnedToBalance;
            }
            else
            {
                txtPrintingInfo.Text = ResourcesMessages.txtPrintSuccess + "\r\n" + ResourcesMessages.txtThanksForUsingPrintBox;
                if (!flashEjected) btnPrintMore.Visible = true;
            }
            AlignButtons();
        }

        private void btnInstruction_MouseDown(object sender, MouseEventArgs e)
        {
            PrintBoxApp.Instance.ShowInstruction(this);
        }

        private void btnLeave_MouseDown(object sender, MouseEventArgs e)
        {
            PrintBoxApp.Instance.EndSession();
        }

        private void btnPrintMore_MouseDown(object sender, MouseEventArgs e)
        {
            PrintBoxApp.Instance.OpenFileList(null);
        }

        public void StartPrint()
        {
            btnLeave.Visible = btnPrintMore.Visible = false;
            txtPrintingInfo.Text = ResourcesMessages.txtPrintingWarning;
            Activate();
            Application.DoEvents();
        }
    }
}
