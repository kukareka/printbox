﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net;

namespace PrintBoxMain
{
    public partial class MaintenanceForm : Form
    {
        private System.ComponentModel.ComponentResourceManager resources;

        public MaintenanceForm()
        {
            WinApi.SuspendDrawing(this);
            InitializeComponent();
            resources = new ComponentResourceManager(typeof(MaintenanceForm));
            lblBoxID.Text = ResourcesMessages.txtBoxID.Replace("<!--BoxID-->", PrintBoxApp.Instance.config.BoxID.ToString());
            WinApi.ResumeDrawing(this);
        }

        public void Login()
        {
            pnlMaintenance.Visible = false;
            keyboardPassword.Reset();
            keyboardPassword.Visible = true;
            this.Activate();
        }

        private void keyboardPassword_CancelButtonClicked(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.adsForm.Activate();
        }

        private void keyboardPassword_OkButtonClicked(object sender, EventArgs e)
        {
            if (keyboardPassword.Value == "357159")
            {
                PrintBoxApp.Instance.MaintenanceInProgress = true;
                keyboardPassword.Visible = false;
                pnlMaintenance.Visible = true;
            }
            else
            {
                PrintBoxApp.Instance.ShowError(this, ResourcesMessages.msgWrongPassword);
                keyboardPassword.Reset();
            }
        }

        private void btnPaper_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.state.PaperInside = PrintBoxApp.Instance.config.MaxPaper;
        }

        private void btnMoney_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.state.BanknotesInside = 0;
            PrintBoxApp.Instance.state.MoneyInside = 0;
        }

        private void btnTestAll_Click(object sender, EventArgs e)
        {
            uint errors = PrintBoxApp.Instance.DetectErrors();
            string[] errorDesc = PrintBoxApp.Instance.DecodeErrors(errors);
            bool pingRes = PrintBoxApp.Instance.server.SendPing();
            PrintBoxApp.Instance.ShowMessage(this, "Помилки: {0}.\r\nСервер: {1}.", 
                errorDesc.Length > 0 ? string.Join("; ", errorDesc) : "Немає",
                pingRes ? "OK" : "Disconnected");
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.server.SendMaintenance();
            pnlMaintenance.Visible = false;
            keyboardPassword.Reset();
            keyboardPassword.Visible = true;
            PrintBoxApp.Instance.EndMaintenance();
        }
    }
}
