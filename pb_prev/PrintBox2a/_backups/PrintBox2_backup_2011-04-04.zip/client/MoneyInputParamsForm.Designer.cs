﻿namespace PrintBoxMain
{
    partial class MoneyInputParamsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MoneyInputParamsForm));
            this.pnlTooltip = new System.Windows.Forms.Panel();
            this.lblAttention = new System.Windows.Forms.Label();
            this.lblTooltip = new System.Windows.Forms.Label();
            this.pnlBalanceInfo = new System.Windows.Forms.Panel();
            this.lblAcceptMoney = new System.Windows.Forms.Label();
            this.checkAcceptMoney = new System.Windows.Forms.CheckBox();
            this.pnlPrintCost = new System.Windows.Forms.Panel();
            this.txtPrintCost = new System.Windows.Forms.Label();
            this.pnlPrintInfo = new System.Windows.Forms.Panel();
            this.lblPagesPerSheet = new System.Windows.Forms.Label();
            this.lblPrintPagesFromTo = new System.Windows.Forms.Label();
            this.lblPagesTotal = new System.Windows.Forms.Label();
            this.lblCopyNumber = new System.Windows.Forms.Label();
            this.pnlDeposit = new System.Windows.Forms.Panel();
            this.txtDeposit = new System.Windows.Forms.Label();
            this.lblDeposit = new System.Windows.Forms.Label();
            this.pnlLeftToDeposit = new System.Windows.Forms.Panel();
            this.txtLeftToDeposit = new System.Windows.Forms.Label();
            this.lblLeftToDeposit = new System.Windows.Forms.Label();
            this.lblPrintCost = new System.Windows.Forms.Label();
            this.pnlOuterPhoneNumber = new System.Windows.Forms.Panel();
            this.lblPrintPage = new System.Windows.Forms.Label();
            this.pnlInnerPhoneNumber = new System.Windows.Forms.Panel();
            this.txtPhoneNumber = new System.Windows.Forms.Label();
            this.btnInstruction = new System.Windows.Forms.ImageButton();
            this.keyboardPassword = new PrintBoxMain.UserControls.KeyboardPanel();
            this.keyboardPhone = new PrintBoxMain.UserControls.KeyboardPanel();
            this.pnlTooltip.SuspendLayout();
            this.pnlBalanceInfo.SuspendLayout();
            this.pnlPrintCost.SuspendLayout();
            this.pnlPrintInfo.SuspendLayout();
            this.pnlDeposit.SuspendLayout();
            this.pnlLeftToDeposit.SuspendLayout();
            this.pnlOuterPhoneNumber.SuspendLayout();
            this.pnlInnerPhoneNumber.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnInstruction)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlTooltip
            // 
            this.pnlTooltip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlTooltip.BackColor = System.Drawing.Color.Transparent;
            this.pnlTooltip.BackgroundImage = global::PrintBoxMain.ResourcesMessages.money_params_info_fon;
            this.pnlTooltip.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlTooltip.Controls.Add(this.lblAttention);
            this.pnlTooltip.Controls.Add(this.lblTooltip);
            this.pnlTooltip.Location = new System.Drawing.Point(9, 526);
            this.pnlTooltip.Margin = new System.Windows.Forms.Padding(0);
            this.pnlTooltip.Name = "pnlTooltip";
            this.pnlTooltip.Size = new System.Drawing.Size(400, 240);
            this.pnlTooltip.TabIndex = 110;
            // 
            // lblAttention
            // 
            this.lblAttention.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblAttention.ForeColor = System.Drawing.Color.Red;
            this.lblAttention.Location = new System.Drawing.Point(5, 110);
            this.lblAttention.Margin = new System.Windows.Forms.Padding(0);
            this.lblAttention.Name = "lblAttention";
            this.lblAttention.Size = new System.Drawing.Size(390, 124);
            this.lblAttention.TabIndex = 103;
            this.lblAttention.Text = "Увага! Повідомлення відправляється тільки один раз, при першому вводі номера. Для" +
                " відновлення пароля зверніться до служби підтримки.";
            // 
            // lblTooltip
            // 
            this.lblTooltip.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTooltip.Location = new System.Drawing.Point(5, 5);
            this.lblTooltip.Margin = new System.Windows.Forms.Padding(0);
            this.lblTooltip.Name = "lblTooltip";
            this.lblTooltip.Size = new System.Drawing.Size(390, 100);
            this.lblTooltip.TabIndex = 103;
            this.lblTooltip.Text = "Введіть номер Вашого телефону. На нього буде віправлено SMS-повідомлення із парол" +
                "ем для доступу до особистого рахунку.";
            // 
            // pnlBalanceInfo
            // 
            this.pnlBalanceInfo.BackColor = System.Drawing.Color.Transparent;
            this.pnlBalanceInfo.Controls.Add(this.lblAcceptMoney);
            this.pnlBalanceInfo.Controls.Add(this.checkAcceptMoney);
            this.pnlBalanceInfo.Controls.Add(this.pnlPrintCost);
            this.pnlBalanceInfo.Controls.Add(this.pnlPrintInfo);
            this.pnlBalanceInfo.Controls.Add(this.pnlDeposit);
            this.pnlBalanceInfo.Controls.Add(this.lblDeposit);
            this.pnlBalanceInfo.Controls.Add(this.pnlLeftToDeposit);
            this.pnlBalanceInfo.Controls.Add(this.lblLeftToDeposit);
            this.pnlBalanceInfo.Controls.Add(this.lblPrintCost);
            this.pnlBalanceInfo.Location = new System.Drawing.Point(9, 117);
            this.pnlBalanceInfo.Margin = new System.Windows.Forms.Padding(0);
            this.pnlBalanceInfo.Name = "pnlBalanceInfo";
            this.pnlBalanceInfo.Size = new System.Drawing.Size(400, 388);
            this.pnlBalanceInfo.TabIndex = 111;
            this.pnlBalanceInfo.Visible = false;
            // 
            // lblAcceptMoney
            // 
            this.lblAcceptMoney.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblAcceptMoney.Location = new System.Drawing.Point(24, 287);
            this.lblAcceptMoney.Name = "lblAcceptMoney";
            this.lblAcceptMoney.Size = new System.Drawing.Size(368, 95);
            this.lblAcceptMoney.TabIndex = 107;
            this.lblAcceptMoney.Text = resources.GetString("lblAcceptMoney.Text");
            // 
            // checkAcceptMoney
            // 
            this.checkAcceptMoney.AutoSize = true;
            this.checkAcceptMoney.Checked = true;
            this.checkAcceptMoney.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkAcceptMoney.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkAcceptMoney.Location = new System.Drawing.Point(6, 294);
            this.checkAcceptMoney.Name = "checkAcceptMoney";
            this.checkAcceptMoney.Size = new System.Drawing.Size(15, 14);
            this.checkAcceptMoney.TabIndex = 106;
            this.checkAcceptMoney.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.checkAcceptMoney.UseVisualStyleBackColor = true;
            this.checkAcceptMoney.CheckedChanged += new System.EventHandler(this.checkAcceptMoney_CheckedChanged);
            // 
            // pnlPrintCost
            // 
            this.pnlPrintCost.BackColor = System.Drawing.Color.Transparent;
            this.pnlPrintCost.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPrintCost.BackgroundImage")));
            this.pnlPrintCost.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlPrintCost.Controls.Add(this.txtPrintCost);
            this.pnlPrintCost.Location = new System.Drawing.Point(253, 174);
            this.pnlPrintCost.Margin = new System.Windows.Forms.Padding(0);
            this.pnlPrintCost.Name = "pnlPrintCost";
            this.pnlPrintCost.Size = new System.Drawing.Size(148, 32);
            this.pnlPrintCost.TabIndex = 104;
            // 
            // txtPrintCost
            // 
            this.txtPrintCost.AutoSize = true;
            this.txtPrintCost.BackColor = System.Drawing.SystemColors.Window;
            this.txtPrintCost.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtPrintCost.ForeColor = System.Drawing.Color.Red;
            this.txtPrintCost.Location = new System.Drawing.Point(3, 3);
            this.txtPrintCost.MinimumSize = new System.Drawing.Size(142, 26);
            this.txtPrintCost.Name = "txtPrintCost";
            this.txtPrintCost.Size = new System.Drawing.Size(142, 26);
            this.txtPrintCost.TabIndex = 60;
            this.txtPrintCost.Text = "0";
            this.txtPrintCost.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlPrintInfo
            // 
            this.pnlPrintInfo.BackColor = System.Drawing.Color.Transparent;
            this.pnlPrintInfo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPrintInfo.BackgroundImage")));
            this.pnlPrintInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlPrintInfo.Controls.Add(this.lblPagesPerSheet);
            this.pnlPrintInfo.Controls.Add(this.lblPrintPagesFromTo);
            this.pnlPrintInfo.Controls.Add(this.lblPagesTotal);
            this.pnlPrintInfo.Controls.Add(this.lblCopyNumber);
            this.pnlPrintInfo.Location = new System.Drawing.Point(1, 0);
            this.pnlPrintInfo.Margin = new System.Windows.Forms.Padding(0);
            this.pnlPrintInfo.Name = "pnlPrintInfo";
            this.pnlPrintInfo.Size = new System.Drawing.Size(400, 113);
            this.pnlPrintInfo.TabIndex = 59;
            // 
            // lblPagesPerSheet
            // 
            this.lblPagesPerSheet.AutoSize = true;
            this.lblPagesPerSheet.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblPagesPerSheet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.lblPagesPerSheet.Location = new System.Drawing.Point(20, 55);
            this.lblPagesPerSheet.Name = "lblPagesPerSheet";
            this.lblPagesPerSheet.Size = new System.Drawing.Size(216, 24);
            this.lblPagesPerSheet.TabIndex = 59;
            this.lblPagesPerSheet.Text = "Сторінок на аркуші";
            this.lblPagesPerSheet.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPrintPagesFromTo
            // 
            this.lblPrintPagesFromTo.AutoSize = true;
            this.lblPrintPagesFromTo.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblPrintPagesFromTo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.lblPrintPagesFromTo.Location = new System.Drawing.Point(20, 33);
            this.lblPrintPagesFromTo.Name = "lblPrintPagesFromTo";
            this.lblPrintPagesFromTo.Size = new System.Drawing.Size(262, 24);
            this.lblPrintPagesFromTo.TabIndex = 58;
            this.lblPrintPagesFromTo.Text = "Друкувати сторінки з по";
            this.lblPrintPagesFromTo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPagesTotal
            // 
            this.lblPagesTotal.AutoSize = true;
            this.lblPagesTotal.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblPagesTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.lblPagesTotal.Location = new System.Drawing.Point(20, 77);
            this.lblPagesTotal.Name = "lblPagesTotal";
            this.lblPagesTotal.Size = new System.Drawing.Size(285, 24);
            this.lblPagesTotal.TabIndex = 56;
            this.lblPagesTotal.Text = "Усього сторінок до друку:";
            this.lblPagesTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblCopyNumber
            // 
            this.lblCopyNumber.AutoSize = true;
            this.lblCopyNumber.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCopyNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.lblCopyNumber.Location = new System.Drawing.Point(20, 11);
            this.lblCopyNumber.Name = "lblCopyNumber";
            this.lblCopyNumber.Size = new System.Drawing.Size(65, 24);
            this.lblCopyNumber.TabIndex = 57;
            this.lblCopyNumber.Text = "Копій";
            this.lblCopyNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlDeposit
            // 
            this.pnlDeposit.BackColor = System.Drawing.Color.Transparent;
            this.pnlDeposit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlDeposit.BackgroundImage")));
            this.pnlDeposit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlDeposit.Controls.Add(this.txtDeposit);
            this.pnlDeposit.Location = new System.Drawing.Point(253, 138);
            this.pnlDeposit.Name = "pnlDeposit";
            this.pnlDeposit.Size = new System.Drawing.Size(148, 32);
            this.pnlDeposit.TabIndex = 98;
            // 
            // txtDeposit
            // 
            this.txtDeposit.AutoSize = true;
            this.txtDeposit.BackColor = System.Drawing.SystemColors.Window;
            this.txtDeposit.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtDeposit.ForeColor = System.Drawing.Color.Red;
            this.txtDeposit.Location = new System.Drawing.Point(3, 3);
            this.txtDeposit.MinimumSize = new System.Drawing.Size(142, 26);
            this.txtDeposit.Name = "txtDeposit";
            this.txtDeposit.Size = new System.Drawing.Size(142, 26);
            this.txtDeposit.TabIndex = 60;
            this.txtDeposit.Text = "0";
            this.txtDeposit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDeposit
            // 
            this.lblDeposit.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblDeposit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.lblDeposit.Location = new System.Drawing.Point(1, 137);
            this.lblDeposit.Name = "lblDeposit";
            this.lblDeposit.Size = new System.Drawing.Size(240, 32);
            this.lblDeposit.TabIndex = 37;
            this.lblDeposit.Text = "Баланс рахунку:";
            this.lblDeposit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlLeftToDeposit
            // 
            this.pnlLeftToDeposit.BackColor = System.Drawing.Color.Transparent;
            this.pnlLeftToDeposit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlLeftToDeposit.BackgroundImage")));
            this.pnlLeftToDeposit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlLeftToDeposit.Controls.Add(this.txtLeftToDeposit);
            this.pnlLeftToDeposit.Location = new System.Drawing.Point(253, 211);
            this.pnlLeftToDeposit.Name = "pnlLeftToDeposit";
            this.pnlLeftToDeposit.Size = new System.Drawing.Size(148, 32);
            this.pnlLeftToDeposit.TabIndex = 99;
            // 
            // txtLeftToDeposit
            // 
            this.txtLeftToDeposit.AutoSize = true;
            this.txtLeftToDeposit.BackColor = System.Drawing.SystemColors.Window;
            this.txtLeftToDeposit.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtLeftToDeposit.ForeColor = System.Drawing.Color.Red;
            this.txtLeftToDeposit.Location = new System.Drawing.Point(3, 3);
            this.txtLeftToDeposit.MinimumSize = new System.Drawing.Size(142, 26);
            this.txtLeftToDeposit.Name = "txtLeftToDeposit";
            this.txtLeftToDeposit.Size = new System.Drawing.Size(142, 26);
            this.txtLeftToDeposit.TabIndex = 60;
            this.txtLeftToDeposit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblLeftToDeposit
            // 
            this.lblLeftToDeposit.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblLeftToDeposit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.lblLeftToDeposit.Location = new System.Drawing.Point(1, 211);
            this.lblLeftToDeposit.Margin = new System.Windows.Forms.Padding(0);
            this.lblLeftToDeposit.Name = "lblLeftToDeposit";
            this.lblLeftToDeposit.Size = new System.Drawing.Size(240, 32);
            this.lblLeftToDeposit.TabIndex = 39;
            this.lblLeftToDeposit.Text = "Залишилось внести:";
            this.lblLeftToDeposit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPrintCost
            // 
            this.lblPrintCost.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblPrintCost.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.lblPrintCost.Location = new System.Drawing.Point(1, 174);
            this.lblPrintCost.Name = "lblPrintCost";
            this.lblPrintCost.Size = new System.Drawing.Size(240, 32);
            this.lblPrintCost.TabIndex = 35;
            this.lblPrintCost.Text = "Вартість друку:";
            this.lblPrintCost.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlOuterPhoneNumber
            // 
            this.pnlOuterPhoneNumber.Controls.Add(this.lblPrintPage);
            this.pnlOuterPhoneNumber.Controls.Add(this.pnlInnerPhoneNumber);
            this.pnlOuterPhoneNumber.Location = new System.Drawing.Point(18, 12);
            this.pnlOuterPhoneNumber.Name = "pnlOuterPhoneNumber";
            this.pnlOuterPhoneNumber.Size = new System.Drawing.Size(300, 72);
            this.pnlOuterPhoneNumber.TabIndex = 109;
            this.pnlOuterPhoneNumber.Visible = false;
            // 
            // lblPrintPage
            // 
            this.lblPrintPage.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblPrintPage.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(70)))), ((int)(((byte)(123)))));
            this.lblPrintPage.Location = new System.Drawing.Point(0, 0);
            this.lblPrintPage.Margin = new System.Windows.Forms.Padding(0);
            this.lblPrintPage.Name = "lblPrintPage";
            this.lblPrintPage.Size = new System.Drawing.Size(270, 32);
            this.lblPrintPage.TabIndex = 103;
            this.lblPrintPage.Text = "Номер телефону:";
            // 
            // pnlInnerPhoneNumber
            // 
            this.pnlInnerPhoneNumber.BackColor = System.Drawing.Color.Transparent;
            this.pnlInnerPhoneNumber.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlInnerPhoneNumber.BackgroundImage")));
            this.pnlInnerPhoneNumber.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlInnerPhoneNumber.Controls.Add(this.txtPhoneNumber);
            this.pnlInnerPhoneNumber.Location = new System.Drawing.Point(0, 40);
            this.pnlInnerPhoneNumber.Name = "pnlInnerPhoneNumber";
            this.pnlInnerPhoneNumber.Size = new System.Drawing.Size(252, 32);
            this.pnlInnerPhoneNumber.TabIndex = 97;
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.BackColor = System.Drawing.SystemColors.Window;
            this.txtPhoneNumber.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtPhoneNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.txtPhoneNumber.Location = new System.Drawing.Point(3, 3);
            this.txtPhoneNumber.MinimumSize = new System.Drawing.Size(142, 26);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(246, 26);
            this.txtPhoneNumber.TabIndex = 60;
            this.txtPhoneNumber.Text = "+380988525062";
            this.txtPhoneNumber.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnInstruction
            // 
            this.btnInstruction.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnInstruction.DownImage = null;
            this.btnInstruction.HoverImage = null;
            this.btnInstruction.Location = new System.Drawing.Point(371, 20);
            this.btnInstruction.Margin = new System.Windows.Forms.Padding(0);
            this.btnInstruction.Name = "btnInstruction";
            this.btnInstruction.NormalImage = ((System.Drawing.Image)(resources.GetObject("btnInstruction.NormalImage")));
            this.btnInstruction.Size = new System.Drawing.Size(63, 83);
            this.btnInstruction.TabIndex = 108;
            this.btnInstruction.TabStop = false;
            // 
            // keyboardPassword
            // 
            this.keyboardPassword.BackColor = System.Drawing.Color.Transparent;
            this.keyboardPassword.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("keyboardPassword.BackgroundImage")));
            this.keyboardPassword.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.keyboardPassword.LabelText = "Введіть Ваш пароль:";
            this.keyboardPassword.Location = new System.Drawing.Point(9, 136);
            this.keyboardPassword.Name = "keyboardPassword";
            this.keyboardPassword.Size = new System.Drawing.Size(400, 322);
            this.keyboardPassword.TabIndex = 113;
            this.keyboardPassword.TextBoxMaxLength = 7;
            this.keyboardPassword.Visible = false;
            this.keyboardPassword.CancelButtonClicked += new PrintBoxMain.UserControls.KeyboardPanel.CancelButtonHandler(this.keyboardPassword_CancelButtonClicked);
            this.keyboardPassword.OkButtonClicked += new PrintBoxMain.UserControls.KeyboardPanel.OkButtonHandler(this.keyboardPassword_OkButtonClicked);
            // 
            // keyboardPhone
            // 
            this.keyboardPhone.BackColor = System.Drawing.Color.Transparent;
            this.keyboardPhone.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("keyboardPhone.BackgroundImage")));
            this.keyboardPhone.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.keyboardPhone.InputValueType = PrintBoxMain.UserControls.KeyboardPanel.ValueType.PhoneNumber;
            this.keyboardPhone.IsSecureTextBox = false;
            this.keyboardPhone.LabelRows = 2;
            this.keyboardPhone.LabelText = "Введіть номер Вашого телефону:";
            this.keyboardPhone.Location = new System.Drawing.Point(9, 117);
            this.keyboardPhone.Margin = new System.Windows.Forms.Padding(0);
            this.keyboardPhone.Name = "keyboardPhone";
            this.keyboardPhone.ShowCancelButton = false;
            this.keyboardPhone.Size = new System.Drawing.Size(400, 352);
            this.keyboardPhone.TabIndex = 112;
            this.keyboardPhone.TextBoxMaxLength = 9;
            this.keyboardPhone.OkButtonClicked += new PrintBoxMain.UserControls.KeyboardPanel.OkButtonHandler(this.keyboardPhone_OkButtonClicked);
            // 
            // MoneyInputParamsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1113, 775);
            this.ControlBox = false;
            this.Controls.Add(this.pnlTooltip);
            this.Controls.Add(this.pnlBalanceInfo);
            this.Controls.Add(this.keyboardPassword);
            this.Controls.Add(this.keyboardPhone);
            this.Controls.Add(this.pnlOuterPhoneNumber);
            this.Controls.Add(this.btnInstruction);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MoneyInputParamsForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.TransparencyKey = System.Drawing.Color.Gray;
            this.Deactivate += new System.EventHandler(this.MoneyInputParamsForm_Deactivate);
            this.Activated += new System.EventHandler(this.MoneyInputParamsForm_Activated);
            this.pnlTooltip.ResumeLayout(false);
            this.pnlBalanceInfo.ResumeLayout(false);
            this.pnlBalanceInfo.PerformLayout();
            this.pnlPrintCost.ResumeLayout(false);
            this.pnlPrintCost.PerformLayout();
            this.pnlPrintInfo.ResumeLayout(false);
            this.pnlPrintInfo.PerformLayout();
            this.pnlDeposit.ResumeLayout(false);
            this.pnlDeposit.PerformLayout();
            this.pnlLeftToDeposit.ResumeLayout(false);
            this.pnlLeftToDeposit.PerformLayout();
            this.pnlOuterPhoneNumber.ResumeLayout(false);
            this.pnlInnerPhoneNumber.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnInstruction)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlTooltip;
        private System.Windows.Forms.Label lblAttention;
        private System.Windows.Forms.Label lblTooltip;
        private System.Windows.Forms.Panel pnlBalanceInfo;
        private System.Windows.Forms.Panel pnlPrintCost;
        private System.Windows.Forms.Label txtPrintCost;
        private System.Windows.Forms.Panel pnlPrintInfo;
        private System.Windows.Forms.Label lblPagesPerSheet;
        private System.Windows.Forms.Label lblPrintPagesFromTo;
        private System.Windows.Forms.Label lblPagesTotal;
        private System.Windows.Forms.Label lblCopyNumber;
        private System.Windows.Forms.Panel pnlDeposit;
        private System.Windows.Forms.Label txtDeposit;
        private System.Windows.Forms.Label lblDeposit;
        private System.Windows.Forms.Panel pnlLeftToDeposit;
        private System.Windows.Forms.Label txtLeftToDeposit;
        private System.Windows.Forms.Label lblLeftToDeposit;
        private System.Windows.Forms.Label lblPrintCost;
        private PrintBoxMain.UserControls.KeyboardPanel keyboardPassword;
        private PrintBoxMain.UserControls.KeyboardPanel keyboardPhone;
        private System.Windows.Forms.Panel pnlOuterPhoneNumber;
        private System.Windows.Forms.Label lblPrintPage;
        private System.Windows.Forms.Panel pnlInnerPhoneNumber;
        private System.Windows.Forms.Label txtPhoneNumber;
        private System.Windows.Forms.ImageButton btnInstruction;
        private System.Windows.Forms.CheckBox checkAcceptMoney;
        private System.Windows.Forms.Label lblAcceptMoney;


    }
}