﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace PrintBoxMain
{
    public partial class MessageForm : Form
    {
        public MessageForm()
        {
            WinApi.SuspendDrawing(this);
            InitializeComponent();
            Left = (1280 - Width) / 2;
            Top = (1024 - Height) / 2;
            if (PrintBoxApp.Instance.TopMost) TopMost = true;
            WinApi.ResumeDrawing(this);
        }

        public void SetMessage(Color color, string msg)
        {
            txtMessage.ForeColor = color;
            txtMessage.Text = msg;
        }

        private void btnOk_MouseDown(object sender, MouseEventArgs e)
        {
            this.Close();
        }
    }
}
