﻿namespace PrintBoxMain
{
    partial class DocumentChooseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DocumentChooseForm));
            this.txtAddressLine = new System.Windows.Forms.Label();
            this.imgList = new System.Windows.Forms.ImageList(this.components);
            this.btnUpper = new System.Windows.Forms.ImageButton();
            this.lblAddress = new System.Windows.Forms.Label();
            this.pnlFilesList = new System.Windows.Forms.Panel();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.btnScrollDown = new System.Windows.Forms.ImageButton();
            this.btnScrollUp = new System.Windows.Forms.ImageButton();
            this.lblBoxID = new System.Windows.Forms.Label();
            this.pnlAddressLine = new System.Windows.Forms.Panel();
            this.btnInstruction = new System.Windows.Forms.ImageButton();
            this.lvFiles = new PrintBoxMain.CustomListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            ((System.ComponentModel.ISupportInitialize)(this.btnUpper)).BeginInit();
            this.pnlFilesList.SuspendLayout();
            this.pnlMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnScrollDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnScrollUp)).BeginInit();
            this.pnlAddressLine.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnInstruction)).BeginInit();
            this.SuspendLayout();
            // 
            // txtAddressLine
            // 
            this.txtAddressLine.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAddressLine.AutoSize = true;
            this.txtAddressLine.BackColor = System.Drawing.Color.Transparent;
            this.txtAddressLine.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtAddressLine.Location = new System.Drawing.Point(3, 3);
            this.txtAddressLine.Margin = new System.Windows.Forms.Padding(3);
            this.txtAddressLine.Name = "txtAddressLine";
            this.txtAddressLine.Size = new System.Drawing.Size(53, 30);
            this.txtAddressLine.TabIndex = 14;
            this.txtAddressLine.Text = "D:\\";
            this.txtAddressLine.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // imgList
            // 
            this.imgList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgList.ImageStream")));
            this.imgList.TransparentColor = System.Drawing.Color.Transparent;
            this.imgList.Images.SetKeyName(0, "folder_open.png");
            this.imgList.Images.SetKeyName(1, "word.ico");
            // 
            // btnUpper
            // 
            this.btnUpper.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpper.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnUpper.DownImage = null;
            this.btnUpper.HoverImage = null;
            this.btnUpper.Location = new System.Drawing.Point(654, 34);
            this.btnUpper.Margin = new System.Windows.Forms.Padding(0);
            this.btnUpper.Name = "btnUpper";
            this.btnUpper.NormalImage = ((System.Drawing.Image)(resources.GetObject("btnUpper.NormalImage")));
            this.btnUpper.Size = new System.Drawing.Size(153, 64);
            this.btnUpper.TabIndex = 18;
            this.btnUpper.TabStop = false;
            this.btnUpper.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnUpper_MouseDown);
            // 
            // lblAddress
            // 
            this.lblAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblAddress.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblAddress.Location = new System.Drawing.Point(13, 60);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(131, 38);
            this.lblAddress.TabIndex = 20;
            this.lblAddress.Text = "Адреса: ";
            this.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlFilesList
            // 
            this.pnlFilesList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlFilesList.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlFilesList.BackgroundImage")));
            this.pnlFilesList.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlFilesList.Controls.Add(this.lvFiles);
            this.pnlFilesList.Location = new System.Drawing.Point(19, 128);
            this.pnlFilesList.Name = "pnlFilesList";
            this.pnlFilesList.Size = new System.Drawing.Size(788, 425);
            this.pnlFilesList.TabIndex = 22;
            // 
            // pnlMain
            // 
            this.pnlMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlMain.BackgroundImage")));
            this.pnlMain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlMain.Controls.Add(this.btnScrollDown);
            this.pnlMain.Controls.Add(this.pnlFilesList);
            this.pnlMain.Controls.Add(this.btnScrollUp);
            this.pnlMain.Controls.Add(this.lblBoxID);
            this.pnlMain.Controls.Add(this.pnlAddressLine);
            this.pnlMain.Controls.Add(this.btnInstruction);
            this.pnlMain.Controls.Add(this.lblAddress);
            this.pnlMain.Controls.Add(this.btnUpper);
            this.pnlMain.Location = new System.Drawing.Point(70, 24);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(915, 668);
            this.pnlMain.TabIndex = 24;
            // 
            // btnScrollDown
            // 
            this.btnScrollDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnScrollDown.BackColor = System.Drawing.Color.Transparent;
            this.btnScrollDown.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnScrollDown.DownImage = ((System.Drawing.Image)(resources.GetObject("btnScrollDown.DownImage")));
            this.btnScrollDown.HoverImage = null;
            this.btnScrollDown.Location = new System.Drawing.Point(823, 475);
            this.btnScrollDown.Margin = new System.Windows.Forms.Padding(0);
            this.btnScrollDown.Name = "btnScrollDown";
            this.btnScrollDown.NormalImage = ((System.Drawing.Image)(resources.GetObject("btnScrollDown.NormalImage")));
            this.btnScrollDown.Size = new System.Drawing.Size(78, 78);
            this.btnScrollDown.TabIndex = 94;
            this.btnScrollDown.TabStop = false;
            this.btnScrollDown.Visible = false;
            this.btnScrollDown.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnScrollDown_MouseDown);
            // 
            // btnScrollUp
            // 
            this.btnScrollUp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnScrollUp.BackColor = System.Drawing.Color.Transparent;
            this.btnScrollUp.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnScrollUp.DownImage = ((System.Drawing.Image)(resources.GetObject("btnScrollUp.DownImage")));
            this.btnScrollUp.HoverImage = null;
            this.btnScrollUp.Location = new System.Drawing.Point(823, 128);
            this.btnScrollUp.Margin = new System.Windows.Forms.Padding(0);
            this.btnScrollUp.Name = "btnScrollUp";
            this.btnScrollUp.NormalImage = ((System.Drawing.Image)(resources.GetObject("btnScrollUp.NormalImage")));
            this.btnScrollUp.Size = new System.Drawing.Size(78, 78);
            this.btnScrollUp.TabIndex = 93;
            this.btnScrollUp.TabStop = false;
            this.btnScrollUp.Visible = false;
            this.btnScrollUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnScrollUp_MouseDown);
            // 
            // lblBoxID
            // 
            this.lblBoxID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblBoxID.BackColor = System.Drawing.Color.White;
            this.lblBoxID.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblBoxID.Location = new System.Drawing.Point(3, 647);
            this.lblBoxID.Name = "lblBoxID";
            this.lblBoxID.Size = new System.Drawing.Size(200, 14);
            this.lblBoxID.TabIndex = 9;
            this.lblBoxID.Text = "ID термінала:";
            // 
            // pnlAddressLine
            // 
            this.pnlAddressLine.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlAddressLine.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlAddressLine.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlAddressLine.BackgroundImage")));
            this.pnlAddressLine.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlAddressLine.Controls.Add(this.txtAddressLine);
            this.pnlAddressLine.Location = new System.Drawing.Point(144, 59);
            this.pnlAddressLine.Name = "pnlAddressLine";
            this.pnlAddressLine.Size = new System.Drawing.Size(490, 36);
            this.pnlAddressLine.TabIndex = 21;
            // 
            // btnInstruction
            // 
            this.btnInstruction.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInstruction.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnInstruction.DownImage = null;
            this.btnInstruction.HoverImage = null;
            this.btnInstruction.Location = new System.Drawing.Point(838, 15);
            this.btnInstruction.Margin = new System.Windows.Forms.Padding(0);
            this.btnInstruction.Name = "btnInstruction";
            this.btnInstruction.NormalImage = ((System.Drawing.Image)(resources.GetObject("btnInstruction.NormalImage")));
            this.btnInstruction.Size = new System.Drawing.Size(63, 83);
            this.btnInstruction.TabIndex = 17;
            this.btnInstruction.TabStop = false;
            this.btnInstruction.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnInstruction_MouseDown);
            // 
            // lvFiles
            // 
            this.lvFiles.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.lvFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lvFiles.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lvFiles.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lvFiles.Cursor = System.Windows.Forms.Cursors.Default;
            this.lvFiles.LargeImageList = this.imgList;
            this.lvFiles.Location = new System.Drawing.Point(3, 3);
            this.lvFiles.MultiSelect = false;
            this.lvFiles.Name = "lvFiles";
            this.lvFiles.Size = new System.Drawing.Size(782, 419);
            this.lvFiles.TabIndex = 16;
            this.lvFiles.UseCompatibleStateImageBehavior = false;
            this.lvFiles.Layout += new System.Windows.Forms.LayoutEventHandler(this.lvFiles_Layout);
            this.lvFiles.ListSelectionChanged += new System.EventHandler<PrintBoxMain.CustomListViewSelectionChangedEventArgs>(this.lvFiles_ListSelectionChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Name";
            this.columnHeader1.Width = 320;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Size";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader2.Width = 70;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Date";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader3.Width = 70;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Time";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // DocumentChooseForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1054, 716);
            this.Controls.Add(this.pnlMain);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "DocumentChooseForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Deactivate += new System.EventHandler(this.DocumentChooseForm_Deactivate);
            this.Activated += new System.EventHandler(this.DocumentChooseForm_Activated);
            ((System.ComponentModel.ISupportInitialize)(this.btnUpper)).EndInit();
            this.pnlFilesList.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnScrollDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnScrollUp)).EndInit();
            this.pnlAddressLine.ResumeLayout(false);
            this.pnlAddressLine.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnInstruction)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label txtAddressLine;
        //private System.Windows.Forms.ListView lvFiles;
        private CustomListView lvFiles;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ImageList imgList;
        private System.Windows.Forms.ImageButton btnUpper;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Panel pnlFilesList;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Label lblBoxID;
        private System.Windows.Forms.ImageButton btnInstruction;
        private System.Windows.Forms.ImageButton btnScrollUp;
        private System.Windows.Forms.ImageButton btnScrollDown;
        private System.Windows.Forms.Panel pnlAddressLine;
    }
}