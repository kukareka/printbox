﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PrintBoxMain
{
    public partial class LoadingForm : Form
    {
        public LoadingForm()
        {
            WinApi.SuspendDrawing(this);
            InitializeComponent();
            Left = (1280 - Width) / 2;
            Top = (1024 - Height) / 2;
            if (PrintBoxApp.Instance.TopMost) TopMost = true;
            WinApi.ResumeDrawing(this);
        }
    }
}
