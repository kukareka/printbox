﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Configuration;
using Microsoft.Win32;
using System.Diagnostics;
using System.Threading;

namespace PrintBoxMain
{
    public partial class AdsForm : Form
    {
        public AdsForm()
        {
            //WinApi.SuspendDrawing(this);
            InitializeComponent();
            InitForm();
            //WinApi.ResumeDrawing(this);
        }

        private void InitForm()
        {            
            //pnlMain.Top = 0;
            //pnlMain.Left = 36;
            //pnlMain.Height = this.Height;
            //pnlMain.Width = this.Width - 2 * pnlMain.Left;
            //btnInstruction.Left = pnlMain.Width - btnInstruction.Width - 28;
            //btnInstruction.Top = 23;
            //lblBoxID.Left = 3;
            //lblBoxID.Top = pnlMain.Height - 55;
            lblBoxID.Text = ResourcesMessages.txtBoxID.Replace("<!--BoxID-->", PrintBoxApp.Instance.config.BoxID.ToString());
            //lblPagesLeft.Top = pnlMain.Height - 55;
            //lblPagesLeft.Left = pnlMain.Width - lblPagesLeft.Width;
            //pbLargeLogo.Top = 203;
            //pbLargeLogo.Left = 229;
            //lblStartWorkTooltip.Left = pbLargeLogo.Left;
            //lblStartWorkTooltip.Width = pbLargeLogo.Width;
            //lblStartWorkTooltip.Top = lblPagesLeft.Top - lblLine2.Height - 30;
            //lblStartWorkTooltip.Text = ResourcesMessages.txtStartWorkMessage;
            //lblLine2.Left = pbLargeLogo.Left;
            //lblLine2.Width = pbLargeLogo.Width;
            //lblLine2.Top = lblStartWorkTooltip.Top - lblLine2.Height - 50;
            //lblLine2.Text = ResourcesMessages.txtPrintPrice;
            //lblLine1.Left = pbLargeLogo.Left;
            //lblLine1.Width = pbLargeLogo.Width;
            //lblLine1.Top = lblLine2.Top - lblLine1.Height;
            //lblLine1.Text = ResourcesMessages.txtPrint;

            lblLine2.Text = String.Format(lblLine2.Text, PrintBoxApp.Instance.config.PageCost);
            SetCleanPaperLeftText();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void SetCleanPaperLeftText()
        {
            lblPagesLeft.Text = ResourcesMessages.txtCleanPaperLeft.Replace("<!--paperLeft-->", PrintBoxApp.Instance.state.PaperInside.ToString());
            //if (lblPagesLeft.InvokeRequired)
            //{
            //    lblPagesLeft.Invoke(new UpdateCleanPaperLeftInfo(SetCleanPaperLeftText));
            //}
            //else
            //{
            //    text;
            //}
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WinApi.WM_DEVICECHANGE) PrintBoxApp.Instance.ProcessMessage(m);
            base.WndProc(ref m);
        }

        private void btnInstruction_MouseDown(object sender, MouseEventArgs e)
        {
            PrintBoxApp.Instance.ShowInstruction(this);
        }

        private void lblBoxID_MouseDown(object sender, MouseEventArgs e)
        {
            //if (!bgLoadMaintenaceForm.IsBusy)
            //{
            //    pbApp.ShowLoadingForm(true, this);
            //    bgLoadMaintenaceForm.RunWorkerAsync();
            //}
        }

        private void lblBoxID_Click(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.BeginMaintenance();
        }

        private void AdsForm_Activated(object sender, EventArgs e)
        {
            SetCleanPaperLeftText();
        }
    }
}
