﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using PrintBoxMain.UserControls;
using System.Diagnostics;

namespace PrintBoxMain
{
    public partial class MoneyInputParamsForm : Form
    {
        public MoneyInputParamsForm()
        {
            WinApi.SuspendDrawing(this);
            InitializeComponent();
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer, true);
            if (PrintBoxApp.Instance.TopMost) TopMost = true;
            InitParams();
            WinApi.ResumeDrawing(this);
        }

        public void SetMoneyInputParamsDefaults()
        {
            SetPhoneTooltip();
            txtPhoneNumber.Text = string.Empty;
            pnlOuterPhoneNumber.Visible = false;
            txtDeposit.Text = "0";
            txtPrintCost.Text = "0";
            txtLeftToDeposit.Text = string.Empty;
            pnlBalanceInfo.Visible = false;
            keyboardPassword.Reset();
            keyboardPassword.Visible = false;
            keyboardPhone.Reset();
            keyboardPhone.Visible = true;
        }

        private void InitParams()
        {
            //pbApp = PrintBoxApp.GetInstance;
            //if (!pbApp.DebugMode) Cursor.Hide();
            //logger = Logger.GetInstance;
            //try
            //{
            //    pbApp.MoneyIn += new MoneyInEventHandler(pbApp_MoneyIn);
            //}
            //catch (Exception ex)
            //{
            //    ErrorEvent ev = new ErrorEvent(ex, DateTime.Now.ToUniversalTime(), pbApp.BoxID, pbApp.Session.SessionID);
            //    logger.LogMessage(ev);
            //}
            //pnlOuterPhoneNumber.Visible = false;
            //SetPhoneTooltip();
        }

        //void pbApp_MoneyIn(object sender, MoneyInEventArgs e)
        //{
        //    UpdateMoneyParams();
        //}

        public void UpdateAllParams()
        {
            //PrintSession sess = PrintBoxApp.GetInstance.Session as PrintSession;
            lblCopyNumber.Text = ResourcesMessages.txtCopyNumber.Replace("<!--copyNumber-->", 
                PrintBoxApp.Instance.printOptions.copies.ToString());
            lblPrintPagesFromTo.Text = ResourcesMessages.txtPrintPagesFromTo.Replace("<!--pageFrom-->",
                PrintBoxApp.Instance.printOptions.from.ToString()).
                Replace("<!--pageTo-->", PrintBoxApp.Instance.printOptions.to.ToString());
            lblPagesTotal.Text = ResourcesMessages.txtPagesTotal.Replace("<!--pagesTotal-->",
                PrintBoxApp.Instance.printOptions.pagesToPrint.ToString());
            lblPagesPerSheet.Text = ResourcesMessages.txtPagesPerSheet.Replace("<!--pagesPerSheet-->",
                PrintBoxApp.Instance.printOptions.pagesPerSheet.ToString());
            txtPrintCost.Text = PrintBoxApp.Instance.printOptions.printCost.ToString("F2");
            UpdateMoneyParams();
        }

        public void UpdateMoneyParams()
        {
            //PrintSession sess = PrintBoxApp.GetInstance.Session as PrintSession; 
            if ((PrintBoxApp.Instance.sessionInfo == null) || (PrintBoxApp.Instance.sessionInfo.userPhone == null)) return;
            txtDeposit.Text = PrintBoxApp.Instance.sessionInfo.userMoney.ToString("F2");
            if (PrintBoxApp.Instance.printOptions.printCost > PrintBoxApp.Instance.sessionInfo.userMoney)
            {
                txtLeftToDeposit.ForeColor = Color.Red;
                txtDeposit.ForeColor = Color.Red;
                lblLeftToDeposit.Text = "Залишилось внести:";
                double leftToDeposit = PrintBoxApp.Instance.printOptions.printCost - PrintBoxApp.Instance.sessionInfo.userMoney;
                txtLeftToDeposit.Text = leftToDeposit.ToString("F2");
                PrintBoxApp.Instance.prePrintForm.ShowPrintButton(false);
            }
            else
            {
                txtLeftToDeposit.ForeColor = Color.Green;
                txtDeposit.ForeColor = Color.Green;
                lblLeftToDeposit.Text = "Залишок на рахунку:";
                double leftToDeposit = PrintBoxApp.Instance.sessionInfo.userMoney - PrintBoxApp.Instance.printOptions.printCost;
                txtLeftToDeposit.Text = leftToDeposit.ToString("F2");
                PrintBoxApp.Instance.prePrintForm.ShowPrintButton(true);
            }
        }

        private void btnInstruction_MouseDown(object sender, MouseEventArgs e)
        {
            PrintBoxApp.Instance.ShowInstruction(this.Owner);
        }

        #region IAuthenticable Members

        public string GetPhoneNumber()
        {
            return keyboardPhone.Value;
        }

        public void NewUser()
        {
            //PrepareKeyboardForPasswordInput();
            //pbApp.ShowMessage(this, ResourcesMessages.msgSmsWithPassSent, keyboardPhone.Text);
            //SetPasswordFirstTimeTooltip();
        }

        public void ExistingUser()
        {
            //PrepareKeyboardForPasswordInput();
            //SetPasswordGeneralTooltip();
        }

        #endregion

        private void keyboardPhone_OkButtonClicked(object sender, EventArgs e)
        {
            string phoneNumber = keyboardPhone.Value;
            PrintBoxApp.Instance.ShowLoadingForm(false);
            Application.DoEvents();
            try
            {
                if (PrintBoxApp.Instance.IsExistingUser(phoneNumber))
                {
                    SetPasswordGeneralTooltip();
                }
                else
                {
                    PrintBoxApp.Instance.ShowMessage(this, ResourcesMessages.msgSmsWithPassSent, keyboardPhone.Text);
                    SetPasswordFirstTimeTooltip();
                }
                PrepareKeyboardForPasswordInput();
            }
            catch
            {
                Activate();
                Application.DoEvents();
                PrintBoxApp.Instance.ShowError(this, ResourcesMessages.msgServerUnavailable);
                return;
            }
            Activate();
        }

        private void PrepareKeyboardForPasswordInput()
        {
            pnlOuterPhoneNumber.Visible = true;
            txtPhoneNumber.Text = keyboardPhone.Text;
            keyboardPhone.Visible = false;
            keyboardPassword.Visible = true;
        }

        private void keyboardPassword_CancelButtonClicked(object sender, EventArgs e)
        {
            keyboardPassword.Visible = false;
            SetKeyboardPhoneDefaults();
            keyboardPhone.Visible = true;
            txtPhoneNumber.Text = string.Empty;
            pnlOuterPhoneNumber.Visible = false;
            SetPhoneTooltip();
        }

        private void SetKeyboardPhoneDefaults()
        {
            keyboardPhone.Reset();
        }

        #region IAuthorizable Members

        public void ShowAccountBalance()
        {
            //PrintSession sess = pbApp.Session as PrintSession;
            pnlTooltip.Visible = false;
            keyboardPassword.Visible = false;
            pnlBalanceInfo.Visible = true;
            //btnUseCard.Visible = true;
            UpdateAllParams();
            Application.DoEvents();
            //sess.StartCashCodeTimer(true);
            PrintBoxApp.Instance.CashCodeEnabled = true;
        }

        #endregion

        private void keyboardPassword_OkButtonClicked(object sender, EventArgs e)
        {
            if (!PrintBoxApp.Instance.AuthorizeUser(keyboardPhone.Value, keyboardPassword.Value))
            {
                PrintBoxApp.Instance.ShowError(this, ResourcesMessages.msgWrongPassword);
            }
            else
            {
                ShowAccountBalance();
            }
        }

        private void keyboardCode_OkButtonClicked(object sender, EventArgs e)
        {
            //pbApp.ReplenishBalance(this);
        }

        #region ILockable Members

        public void DisableAllControls()
        {
            //pbApp.ShowLoadingForm(true, this);
            //if (pbApp.Session != null)
            //    this.Activate();
            //else
            //    pbApp.frmAds.Focus();
            //if (keyboardPhone.Visible)
            //    keyboardPhone.EnableDisableAllButtons(false);
            //else
            //    if (keyboardPassword.Visible)
            //        keyboardPassword.EnableDisableAllButtons(false);
            //    else
            //        if (keyboardCardCode.Visible)
            //            keyboardCardCode.EnableDisableAllButtons(false);
            //pbApp.frmPrePrint.DisableAllControls();
        }

        public void EnableAllControls()
        {
            //pbApp.ShowLoadingForm(false, this);
            //if (pbApp.Session != null)
            //    this.Activate();
            //else
            //    pbApp.frmAds.Focus();
            //if (keyboardPhone.Visible)
            //    keyboardPhone.EnableDisableAllButtons(true);
            //else
            //    if (keyboardPassword.Visible)
            //        keyboardPassword.EnableDisableAllButtons(true);
            //    else
            //        if (keyboardCardCode.Visible)
            //            keyboardCardCode.EnableDisableAllButtons(true);
            //pbApp.frmPrePrint.EnableAllControls();
        }

        #endregion

        private void SetPhoneTooltip()
        {
            pnlTooltip.Visible = true;
            lblTooltip.Text = ResourcesMessages.txtPhoneTooltip;
            lblTooltip.Left = 5;
            lblTooltip.Top = 5;
            lblTooltip.Height = 100;
            lblAttention.Text = ResourcesMessages.txtAttentionPhone;
            lblAttention.Left = 5;
            lblAttention.Top = lblTooltip.Bottom;
            lblAttention.Height = 125;
            pnlTooltip.Height = 10 + lblTooltip.Height + lblAttention.Height;
        }

        private void SetPasswordFirstTimeTooltip()
        {
            lblTooltip.Text = ResourcesMessages.txtPasswordFirstTimeTooltip;
            lblTooltip.Left = 5;
            lblTooltip.Top = 5;
            lblTooltip.Height = 50;
            lblAttention.Text = ResourcesMessages.txtAttentionGeneral;
            lblAttention.Left = 5;
            lblAttention.Top = lblTooltip.Bottom;
            lblAttention.Height = 75;
            pnlTooltip.Height = 10 + lblTooltip.Height + lblAttention.Height;
        }

        private void SetPasswordGeneralTooltip()
        {
            lblTooltip.Text = ResourcesMessages.txtPasswordGeneralTooltip;
            lblTooltip.Left = 5;
            lblTooltip.Top = 5;
            lblTooltip.Height = 25;
            lblAttention.Text = ResourcesMessages.txtAttentionGeneral;
            lblAttention.Left = 5;
            lblAttention.Top = lblTooltip.Bottom;
            lblAttention.Height = 75;
            pnlTooltip.Height = 10 + lblTooltip.Height + lblAttention.Height;
        }

        private void MoneyInputParamsForm_Activated(object sender, EventArgs e)
        {
            checkAcceptMoney.Checked = true;
            //Debug.WriteLine("Money Input Params Form activated");
            //StackTrace stack = new StackTrace();
            //StackFrame[] frames = stack.GetFrames();
            //StringBuilder str = new StringBuilder();
            //for (int i = frames.Length - 1; i >= 0; i--)
            //{
            //    if (i > 0)
            //        str.Append(frames[i].GetMethod().Name + " --> ");
            //    else
            //        str.Append(frames[i].GetMethod().Name);
            //}
            //Debug.WriteLine(str.ToString());
        }

        private void MoneyInputParamsForm_Deactivate(object sender, EventArgs e)
        {
            //Debug.WriteLine("Money Input Params Form deactivated");
            //StackTrace stack = new StackTrace();
            //StackFrame[] frames = stack.GetFrames();
            //StringBuilder str = new StringBuilder();
            //for (int i = frames.Length - 1; i >= 0; i--)
            //{
            //    if (i > 0)
            //        str.Append(frames[i].GetMethod().Name + " --> ");
            //    else
            //        str.Append(frames[i].GetMethod().Name);
            //}
            //Debug.WriteLine(str.ToString());
        }

        private void checkAcceptMoney_CheckedChanged(object sender, EventArgs e)
        {
            PrintBoxApp.Instance.prePrintForm.ShowPrintButton(checkAcceptMoney.Checked);
        }
    }
}
