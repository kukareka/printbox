﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using log4net;

namespace PrintBoxMain
{
    public partial class PrePrintForm : Form
    {
        ILog log = LogManager.GetLogger(typeof(PrePrintForm));

        private System.ComponentModel.ComponentResourceManager resources;
                
        public const int WORD_PANEL_WIDTH_NORMAL = 600;
        public const int WORD_PANEL_HEIGHT_NORMAL = 740;
        
        public PrePrintForm()
        {
            WinApi.SuspendDrawing(this);
            InitializeComponent();
            //EnableDisableNavigationButtons(false);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer, true);
            resources = new ComponentResourceManager(typeof(PrePrintForm));
            InitForm();
            /*
            if (!pbApp.DebugMode)
            {
                actHook = new UserActivityHook();
                actHook.OnMouseActivity += new MouseEventHandler(actHook_OnMouseActivity);
                actHook.Stop();
            }
            */
            WinApi.ResumeDrawing(this);
        }

        public void StartLoadingWordDocument()
        {
            //StepBackward();
            lblCurrentPageInfo.Text = string.Empty;
            /*
            frmPrintParams.UpdateFields();
            pbApp.ShowLoadingForm(true, this);
            */
            //bgOpenWord.RunWorkerAsync();
        }

        void actHook_OnMouseActivity(object sender, MouseEventArgs e)
        {
        }

        private void InitForm()
        {
            /*
            if (!pbApp.DebugMode)
            {
                Cursor.Hide();
                WinApi.SetWinFullScreen(this.Handle);
            }
            */

            //pnlMain.Top = 0;
            //pnlMain.Left = 36;
            //pnlMain.Height = this.Height;
            //pnlMain.Width = this.Width - 2 * pnlMain.Left;
            pnlWord.Left = 26;
            pnlWord.Top = 116;
            pnlWord.Width = WORD_PANEL_WIDTH_NORMAL;
            pnlWord.Height = WORD_PANEL_HEIGHT_NORMAL;
            this.BackColor = Color.FromArgb(236, 244, 251);
            /*
            pbApp.WordParentWindowHandler = pnlWord.Handle.ToInt32();
            pbApp.WordWindowWidth = pnlWord.Width;
            pbApp.WordWindowHeight = pnlWord.Height;
            */

            //Set buttons
            //btnScrollUp.Left = 639;
            //btnScrollDown.Left = 639;
            //btnScrollDown.Top = 835;
            //lblCurrentPageInfo.Top = pnlMain.Height - 100;
            //lblCurrentPageInfo.Left = 9;
            //lblCurrentPageInfo.Width = 605;
            //lblCurrentPageInfo.Text = string.Empty;
            //lblBoxID.Left = 3;
            //lblBoxID.Top = this.Height - 55;
            lblBoxID.Text = ResourcesMessages.txtBoxID.Replace("<!--BoxID-->", PrintBoxApp.Instance.config.BoxID.ToString());

            frmMoneyInputParams = new MoneyInputParamsForm();
            frmPrintParams = new PrintParamsForm();

            if (PrintBoxApp.Instance.FullScreen)
            {
                frmPrintParams.Top = frmMoneyInputParams.Top = 30;
                frmPrintParams.Left = frmMoneyInputParams.Left = 795;
            }
            frmPrintParams.Height = frmMoneyInputParams.Height = 860;
            frmPrintParams.Width = frmMoneyInputParams.Width = 454;
            frmPrintParams.Show(this);            
            frmMoneyInputParams.Show(this);
            frmMoneyInputParams.Hide();

            //pnlNavigationButtons.Left = 639;
            //pnlNavigationButtons.Top = 925;
        }


        private void bgOpenWord_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //if (e.Error != null)
            //{
            //    pbApp.ShowMessage(this, ResourcesMessages.msgErrorHappenedWhileOpeningFile);
            //    ErrorEvent ev = new ErrorEvent(e.Error, DateTime.Now.ToUniversalTime(), pbApp.BoxID, pbApp.Session.SessionID);
            //    logger.LogMessage(ev);
            //    btnCancelPrint.Enabled = true;
            //    btnCancelPrint.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_cancel));
            //    pbApp.ShowMessage(this, ResourcesMessages.msgErrorHappenedWhileOpeningFile);
            //}
            //else
            //{
            //    bool result = Convert.ToBoolean(e.Result);
            //    if (!result)
            //    {
            //        ErrorEvent ev = new ErrorEvent("Во время открытия word'а произошла ошибка", DateTime.Now.ToUniversalTime(), pbApp.BoxID, Guid.Empty);
            //        if (pbApp.Session != null)
            //            ev.SessionID = pbApp.Session.SessionID;
            //        logger.LogMessage(ev);
            //        btnCancelPrint.Enabled = true;
            //        btnCancelPrint.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_cancel));
            //        pbApp.ShowMessage(this, ResourcesMessages.msgErrorHappenedWhileOpeningFile);
            //    }
            //    else
            //    {
            //        EnableDisableNavigationButtons(true);
            //        UpdateCurrentPageNumberInfo();
            //        frmPrintParams.EnableDefaultPrintOptions();
            //        actHook.Start();
            //    }
            //}
        }

        private void StepForward()
        {
            if (!PrintBoxApp.Instance.printOptions.valid)
            {
                PrintBoxApp.Instance.ShowError(this, ResourcesMessages.msgInvalidPrintParams);
                return;
            }
            int pagesToPrint = PrintBoxApp.Instance.printOptions.pagesToPrint;
            if (pagesToPrint > 150)
            {
                PrintBoxApp.Instance.ShowError(this, ResourcesMessages.msgMoreThan150PagesForPrint);
                return;
            }
            if (pagesToPrint > PrintBoxApp.Instance.state.PaperInside)
            {
                PrintBoxApp.Instance.ShowError(this, ResourcesMessages.msgNotEnoughPagesForPrint, PrintBoxApp.Instance.state.PaperInside.ToString());
                return;
            }
            if (!PrintBoxApp.Instance.IsPrinterReady())
            {
                PrintBoxApp.Instance.ShowError(this, ResourcesMessages.msgPrinterIsNotReady);
                return;
            }

            WinApi.SuspendDrawing(pnlNavigationButtons);
            btnBack.Visible = true;
            btnNext.Visible = false;
            WinApi.ResumeDrawing(pnlNavigationButtons);

            InvalidateUser();
            frmPrintParams.Hide();
            frmMoneyInputParams.Show(this);
        }

        public void StepBackward()
        {
            WinApi.SuspendDrawing(pnlNavigationButtons);
            btnBack.Visible = false;
            btnPrint.Visible = false;
            btnNext.Visible = true;
            WinApi.ResumeDrawing(pnlNavigationButtons);

            frmMoneyInputParams.Hide();
            frmPrintParams.Show(this);
            PrintBoxApp.Instance.CashCodeEnabled = false;
        }

        public void EnableDisableNavigationButtons(bool flag)
        {
            if (flag)
            {
                btnCancelPrint.Enabled = true;
                btnNext.Enabled = true;
                btnScrollDown.Enabled = true;
                btnScrollUp.Enabled = true;
                btnScrollDown.NormalImage = ((System.Drawing.Image)(ResourcesMessages.scroll_button_down));
                btnScrollUp.NormalImage = ((System.Drawing.Image)(ResourcesMessages.scroll_button_up));
                btnCancelPrint.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_cancel));
                btnNext.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_next));
            }
            else
            {
                btnCancelPrint.Enabled = false;
                btnNext.Enabled = false;
                btnScrollDown.Enabled = false;
                btnScrollUp.Enabled = false;
                btnScrollDown.NormalImage = ((System.Drawing.Image)(ResourcesMessages.scroll_button_down_disabled));
                btnScrollUp.NormalImage = ((System.Drawing.Image)(ResourcesMessages.scroll_button_up_disabled));
                btnCancelPrint.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_cancel_disabled));
                btnNext.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_next_disabled));
            }
        }

        public void EnableDisableAllVisibleButtons(bool flag)
        {
            if (flag)
            {
                if (btnCancelPrint.Visible)
                {
                    WinApi.SuspendDrawing(btnCancelPrint);
                    btnCancelPrint.Enabled = true;
                    btnCancelPrint.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_cancel));
                    WinApi.ResumeDrawing(btnCancelPrint);
                }
                if (btnNext.Visible)
                {
                    WinApi.SuspendDrawing(btnNext);
                    btnNext.Enabled = true;
                    btnNext.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_next));
                    WinApi.ResumeDrawing(btnNext);
                }
                if (btnScrollDown.Visible)
                {
                    WinApi.SuspendDrawing(btnScrollDown);
                    btnScrollDown.Enabled = true;
                    btnScrollDown.NormalImage = ((System.Drawing.Image)(ResourcesMessages.scroll_button_down));
                    WinApi.ResumeDrawing(btnScrollDown);
                }
                if (btnScrollUp.Visible)
                {
                    WinApi.SuspendDrawing(btnScrollUp);
                    btnScrollUp.Enabled = true;
                    btnScrollUp.NormalImage = ((System.Drawing.Image)(ResourcesMessages.scroll_button_up));
                    WinApi.ResumeDrawing(btnScrollUp);
                }
                if (btnPrint.Visible)
                {
                    WinApi.SuspendDrawing(btnPrint);
                    btnPrint.Enabled = true;
                    btnPrint.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_print));
                    WinApi.ResumeDrawing(btnPrint);
                }
                if (btnBack.Visible)
                {
                    WinApi.SuspendDrawing(btnBack);
                    btnBack.Enabled = true;
                    btnBack.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_back));
                    WinApi.ResumeDrawing(btnBack);
                }
            }
            else
            {
                if (btnCancelPrint.Visible)
                {
                    WinApi.SuspendDrawing(btnCancelPrint);
                    btnCancelPrint.Enabled = false;
                    btnCancelPrint.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_cancel_disabled));
                    WinApi.ResumeDrawing(btnCancelPrint);
                }
                if (btnNext.Visible)
                {
                    WinApi.SuspendDrawing(btnNext);
                    btnNext.Enabled = false;
                    btnNext.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_next_disabled));
                    WinApi.ResumeDrawing(btnNext);
                }
                if (btnScrollDown.Visible)
                {
                    WinApi.SuspendDrawing(btnScrollDown);
                    btnScrollDown.Enabled = false;
                    btnScrollDown.NormalImage = ((System.Drawing.Image)(ResourcesMessages.scroll_button_down_disabled));
                    WinApi.ResumeDrawing(btnScrollDown);
                }
                if (btnScrollUp.Visible)
                {
                    WinApi.SuspendDrawing(btnScrollUp);
                    btnScrollUp.Enabled = false;
                    btnScrollUp.NormalImage = ((System.Drawing.Image)(ResourcesMessages.scroll_button_up_disabled));
                    WinApi.ResumeDrawing(btnScrollUp);
                }
                if (btnPrint.Visible)
                {
                    WinApi.SuspendDrawing(btnPrint);
                    btnPrint.Enabled = false;
                    btnPrint.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_print_disabled));
                    WinApi.ResumeDrawing(btnPrint);
                }
                if (btnBack.Visible)
                {
                    WinApi.SuspendDrawing(btnBack);
                    btnBack.Enabled = false;
                    btnBack.NormalImage = ((System.Drawing.Image)(ResourcesMessages.preprint_back_disabled));
                    WinApi.ResumeDrawing(btnBack);
                }
            }
        }

        public void UpdatePageNumber()
        {
            lblCurrentPageInfo.Text = 
                ResourcesMessages.txtCurrentPageInfo.Replace("<!--currentPage-->", PrintBoxApp.Instance.sessionInfo.CurrentPage.ToString()).
                Replace("<!--totalPagesInDocument-->", PrintBoxApp.Instance.sessionInfo.pagesInDoc.ToString());
        }

        private void btnScrollUp_MouseDown(object sender, MouseEventArgs e)
        {
            PrintBoxApp.Instance.sessionInfo.CurrentPage -= 1;
            UpdatePageNumber();
        }

        private void btnScrollDown_MouseDown(object sender, MouseEventArgs e)
        {
            PrintBoxApp.Instance.sessionInfo.CurrentPage += 1;
            UpdatePageNumber();
        }

        private void btnBack_MouseDown(object sender, MouseEventArgs e)
        {
            StepBackward();
        }

        public void btnCancelPrint_MouseDown(object sender, MouseEventArgs e)
        {
            PrintBoxApp.Instance.CashCodeEnabled = false;
            PrintBoxApp.Instance.OpenFileList(null);
        }

        private void btnNext_MouseDown(object sender, MouseEventArgs e)
        {
            StepForward();
        }

        private void btnPrint_MouseDown(object sender, MouseEventArgs e)
        {
            PrintBoxApp.Instance.CashCodeEnabled = false;
            if (PrintBoxApp.Instance.sessionInfo == null) return;
            if (PrintBoxApp.Instance.printOptions.printCost > PrintBoxApp.Instance.sessionInfo.userMoney)
            {
                PrintBoxApp.Instance.ShowError(this, ResourcesMessages.msgNotEnoughMoney);
                return;
            }
            
            PrintBoxApp.Instance.PrintDoc();

            //if (PrintBoxApp.Instance.IsPrinterReady())
            //{
            //    Print

            //    frmPrintParams.SetDefaultPrintOptions();
            //    EnableDisableNavigationButtons(false);
            //    StepBackward();
            //    frmMoneyInputParams.SetMoneyInputParamsDefaults();
            //    pbApp.frmPrint.SetDefaults();
            //    pbApp.frmPrint.BringToFront();
            //}
            //else
            //{
            //    pbApp.ShowMessage(this, ResourcesMessages.msgPrinterIsNotReady);
            //}
        }

        public void ShowPrintButton(bool flag)
        {
            btnPrint.Visible = flag;
        }

        #region ILockable Members

        public void DisableAllControls()
        {
            EnableDisableAllVisibleButtons(false);
        }

        public void EnableAllControls()
        {
            EnableDisableAllVisibleButtons(true);
        }

        #endregion

        private void PrePrintForm_Activated(object sender, EventArgs e)
        {
            log.Debug("activated");            
        }

        private void PrePrintForm_Deactivate(object sender, EventArgs e)
        {
            log.Debug("deactivated");
        }

        public void LoadDocument()
        {
            UpdatePageNumber();
            frmPrintParams.LoadPrintOptions();
            if (!frmPrintParams.Visible) StepBackward();
            InvalidateUser();
            Show();
            BringToFront();
            Activate();
            Application.DoEvents();
            frmPrintParams.Activate();
        }

        public void RefreshMoney()
        {
            frmMoneyInputParams.UpdateMoneyParams();
        }

        internal void InvalidateUser()
        {
            frmMoneyInputParams.SetMoneyInputParamsDefaults();
        }
    }
}
